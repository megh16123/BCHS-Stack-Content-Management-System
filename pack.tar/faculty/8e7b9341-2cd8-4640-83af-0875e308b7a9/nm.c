#include<stdio.h>
int main()
//for(i=0,i<5,i++)
{
int a;
printf("enter the no:");
scanf("%d",&a);
for(int i=0;i<5;i++)
{
a=a+i;
}
printf(" tyagiji aap ka ans %d hai\n",a);
return 0;
}
